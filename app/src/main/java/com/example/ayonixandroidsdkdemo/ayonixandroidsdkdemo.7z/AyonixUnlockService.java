package com.example.ayonixandroidsdkdemo;

import android.app.KeyguardManager;
import android.app.Notification;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.ImageFormat;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraManager;
import android.media.CamcorderProfile;
import android.media.Image;
import android.media.ImageReader;
import android.media.MediaRecorder;
import android.os.IBinder;
import android.support.v4.app.NotificationCompat;
import android.support.v4.content.LocalBroadcastManager;
import android.util.Log;
import android.view.Surface;
import android.view.TextureView;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.util.Timer;
import java.util.TimerTask;
import java.util.Vector;

import ayonix.AyonixException;
import ayonix.AyonixFace;
import ayonix.AyonixFaceID;
import ayonix.AyonixFaceTracker;
import ayonix.AyonixImage;
import ayonix.AyonixLicenseStatus;
import ayonix.AyonixRect;

import static android.content.ContentValues.TAG;
import static android.graphics.ImageFormat.RGB_565;
import static android.provider.MediaStore.Files.FileColumns.MEDIA_TYPE_VIDEO;

import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraCaptureSession;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraDevice;
import android.hardware.camera2.CameraManager;
import android.hardware.camera2.CameraMetadata;
import android.hardware.camera2.CaptureRequest;
import android.hardware.camera2.TotalCaptureResult;
import android.hardware.camera2.params.StreamConfigurationMap;

public class AyonixUnlockService extends Service {

    private AyonixFaceID engine = null;
    private AyonixFaceTracker faceTracker = null;
    private static final String TAG_FOREGROUND_SERVICE = "FOREGROUND_SERVICE";
    public static final String ACTION_START_FOREGROUND_SERVICE = "ACTION_START_FOREGROUND_SERVICE";
    public static final String ACTION_STOP_FOREGROUND_SERVICE = "ACTION_STOP_FOREGROUND_SERVICE";
    public static final String ACTION_PAUSE = "ACTION_PAUSE";
    public static final String ACTION_PLAY = "ACTION_PLAY";

    //Let client decide what minimum match percentage is
    private final int minMatch = 90;
    private final int width = 1024;
    private final int height = 580;
    private final int detectionPeriod = 5;
    private final int minFaceSize = 40;
    private final int maxFaceSize = 300;
    private final float qualityThreshold = 0.6f;
    private int pixels[] = new int[width*height];
    private byte gray[] = new byte[width*height];

    public AyonixUnlockService() { super(); }

    @Override
    public IBinder onBind(Intent intent) { return null; }

    @Override
    public void onCreate() {
        super.onCreate();
        Log.d("AndroidClarified", "Service started.");

        // receive screen on/off broadcasts
        IntentFilter filter = new IntentFilter();
        filter.addAction(Intent.ACTION_SCREEN_ON);
        filter.addAction(Intent.ACTION_SCREEN_OFF);
        registerReceiver(receive, filter);

        // step 1. list assets (and make sure engine and test image are there)
        String engineAssetFiles[] = null;
        try {
            engineAssetFiles = getApplicationContext().getAssets().list("engine0");
        } catch (IOException e) {
        }

        // step 2. get local writable directory, and copy engine to there (for native fopen)
        String filesDir = getFilesDir().toString();

        try {
            File engineFolder = new File(filesDir + "/engine");
            engineFolder.mkdirs();
        } catch (Exception e) {
        }

        for (int i = 0; i < engineAssetFiles.length; i++) {
            String engineFilei = filesDir + "/engine/" + engineAssetFiles[i];
            try {
                InputStream fileIn = getApplicationContext().getAssets().open("engine0/" + engineAssetFiles[i]);
                FileOutputStream fileOut = new FileOutputStream(engineFilei);

                byte[] buffer = new byte[1024];
                int read = 0;
                while ((read = fileIn.read(buffer)) != -1) {
                    fileOut.write(buffer, 0, read);
                }

            } catch (IOException e) {
            }
        }
        Log.v("faceService", "Prepared engine files.");

        // step 3. give local engine folder and license params to init the engine
        try {
            engine = new AyonixFaceID(filesDir + "/engine", 816371403418L, "ju8zyppzgwh7a9qn");
            Log.d("faceService", "Loaded engine");
        } catch (AyonixException e) {
            System.out.format("Caught Ayonix Error %d\n", e.errorCode);
            e.printStackTrace();
        }

        try {
            faceTracker = new AyonixFaceTracker(engine, detectionPeriod, minFaceSize,
                    maxFaceSize, qualityThreshold);
        } catch (AyonixException e) {
            e.printStackTrace();

        }
    }

    public int onStartCommand(Intent intent, int flags, int startId){
        if(intent != null)
        {
            String action = intent.getAction();
            switch (action)
            {
                case ACTION_START_FOREGROUND_SERVICE:
                    startForegroundService();
                    Toast.makeText(getApplicationContext(), "Foreground service is started.", Toast.LENGTH_LONG).show();
                    break;
                case ACTION_STOP_FOREGROUND_SERVICE:
                    stopForegroundService();
                    Toast.makeText(getApplicationContext(), "Foreground service is stopped.", Toast.LENGTH_LONG).show();
                    break;
                case ACTION_PLAY:
                    Toast.makeText(getApplicationContext(), "You click Play button.", Toast.LENGTH_LONG).show();
                    break;
                default:
                    Toast.makeText(getApplicationContext(), "Something went wrong starting service", Toast.LENGTH_LONG).show();
                    break;
            }
        }
        return super.onStartCommand(intent, flags, startId);

        /*super.onStartCommand(intent, flags, startId);
        return START_STICKY;*/
    }

    private void startForegroundService() {
        Log.d("debug", "Start foreground service");

        // Create notification default intent.
        Intent intent = new Intent();
        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, intent, 0);

        // create notification builder
        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, "ayonix");

        // make notification show big text
        NotificationCompat.BigTextStyle bigTextStyle = new NotificationCompat.BigTextStyle();
        bigTextStyle.setBigContentTitle("Ayonix facial recognition implemented by foreground service.");
        bigTextStyle.bigText("Android foreground service is an android service which can run in foreground always," +
                " it can be controlled by user via notification.");
        builder.setStyle(bigTextStyle);
        builder.setWhen(System.currentTimeMillis());
        builder.setSmallIcon(R.mipmap.ic_launcher);
        Bitmap largeIconBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.ic_launcher_foreground);
        builder.setLargeIcon(largeIconBitmap);

        // make the notification max priority: 2 == max ??
        builder.setPriority(2);

        // make head-up notification
        builder.setFullScreenIntent(pendingIntent, true);


        /*// Add Play button intent in notification.
        Intent playIntent = new Intent(this, MyForeGroundService.class);
        playIntent.setAction(ACTION_PLAY);
        PendingIntent pendingPlayIntent = PendingIntent.getService(this, 0, playIntent, 0);
        NotificationCompat.Action playAction = new NotificationCompat.Action(android.R.drawable.ic_media_play, "Play", pendingPlayIntent);
        builder.addAction(playAction);*/

        // build notification and start foreground service
        Notification notification = builder.build();
        startForeground(1, notification);
        Log.d("debug", "notification built and service started");

        /*// setup front camera
        try {
            String cameraId = null;
            Log.d("cameras", "service getting front camera");
            CameraManager manager = (CameraManager) getSystemService(Context.CAMERA_SERVICE);
            for (String camera : manager.getCameraIdList()) {
                CameraCharacteristics characteristics = manager.getCameraCharacteristics(camera);
                int frontCam = characteristics.get(CameraCharacteristics.LENS_FACING);
                cameraId = camera;
                if (frontCam == CameraCharacteristics.LENS_FACING_FRONT) { break; }
            }
        } catch (CameraAccessException e) {
            e.printStackTrace();
        }*/

    }

    private BroadcastReceiver receive = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {

            Log.v("faceService", "received intent.");

            if(Intent.ACTION_SCREEN_ON.equals(intent.getAction())){
                Log.v("faceService", "starting facial recognition...");
                KeyguardManager keyguardManager = (KeyguardManager) getSystemService(Context.KEYGUARD_SERVICE);
                if(keyguardManager.isKeyguardLocked() || keyguardManager.isDeviceLocked()) {

                    final AyonixFaceID engineRef = engine;
                    try {
                         faceTracker = new AyonixFaceTracker(engineRef, detectionPeriod, minFaceSize,
                                maxFaceSize, qualityThreshold);
                    } catch (AyonixException e) {
                        e.printStackTrace();
                    }



                    //AyonixImage frame = new AyonixImage(width, height, true, width, );
                    ImageReader.OnImageAvailableListener mOnImageAvailableListener = new ImageReader.OnImageAvailableListener() {
                        @Override
                        public void onImageAvailable(ImageReader reader) {
                            Image image = null;
                            try {
                            image = reader.acquireLatestImage();
                            //Result rawResult = null;
                                if (image == null) throw new NullPointerException("cannot be null");
                                ByteBuffer buffer = image.getPlanes()[0].getBuffer();
                                byte[] data = new byte[buffer.remaining()];
                                buffer.get(data);
                                Bitmap bitmap = BitmapFactory.decodeByteArray(data, 0, data.length);

                                AyonixImage frame = new AyonixImage(width, height, true, width, data);
                                AyonixRect[] faceRects = engineRef.DetectFaces(frame, 48);

                                AyonixFace[] faces = new AyonixFace[faceRects.length];
                                for(int i = 0; i < faceRects.length; i++){
                                    faces[i] = engineRef.ExtractFaceFromRect(frame, faceRects[i]);
                                    Log.i("info", "  Face[" +(i+1)+ "] " +faceRects[i].w+ "x" +
                                            faceRects[i].h+ " " + (int) (faces[i].age)+ "y " +
                                            (faces[i].gender > 0 ? "female" : "male") + "\n");
                                }
                                // create afids from test faces
                                Vector<byte[]> afidsVec = new Vector<byte[]>();
                                int totalSize = 0;
                                for (int i = 0; i < faces.length; i++) {
                                    byte[] afidi = engineRef.CreateAfid(faces[i]);
                                    afidsVec.add(afidi);
                                    totalSize += afidi.length;
                                }

                                Log.i("info", "Created " + faces.length + " afids\n");
                                Log.i("info", "  Total " + totalSize + " bytes\n");

                                // match faces against each other
                                float[] scores = new float[faces.length];
                                engineRef.MatchAfids(afidsVec.get(0), afidsVec, scores);

                                Log.i("info", "Matched " + faces.length + " afids\n");
                                for (int i = 0; i < faces.length; i++) {
                                    Log.i("info", "  Afid[1] vs Afid[" + (i + 1) + "]: " + (100 * scores[i]) + "\n");
                                }

                                Log.i("info", "Done\n");


                                faceTracker.UpdateTracker(frame);
                                image.close();


                            } catch (/*ReaderException*/ Exception e) {
                                Log.w("warn", e.getMessage());
                            } finally {
                                //mQrReader.reset();
                                if (image != null)
                                    image.close();
                            }
                        }
                    };

                    ImageReader mImageReader = ImageReader.newInstance(width, height, RGB_565, 1);
                    mImageReader.setOnImageAvailableListener(mOnImageAvailableListener, null);



                    // step 4. on button click, load image and process

                    try {
                        InputStream fileIn =  getApplicationContext().getAssets().open("images/angelina-jolie-brad-pitt.jpg");
                        Bitmap img = BitmapFactory.decodeStream(fileIn);

                        /*int pixels[] = new int[img.getWidth() * img.getHeight()];
                        byte gray[] = new byte[img.getWidth() * img.getHeight()];*/

                        img.getPixels(pixels, 0, img.getWidth(), 0, 0, img.getWidth(), img.getHeight());

                        for(int i = 0; i < pixels.length; i++)
                            gray[i] = (byte)(255 * Color.luminance(pixels[i]));

                        AyonixImage aimg = new AyonixImage(img.getWidth(), img.getHeight(), false, img.getWidth(), gray);

                        AyonixRect[] faceRects = engineRef.DetectFaces(aimg, 48);

                        AyonixFace[] faces = new AyonixFace[faceRects.length];
                        for(int i = 0; i < faceRects.length; i++)
                        {
                            faces[i] = engineRef.ExtractFaceFromRect(aimg, faceRects[i]);
                        }

                        // create afids from test faces
                        Vector<byte[]> afidsVec = new Vector<byte[]>();
                        int totalSize = 0;
                        for(int i = 0; i < faces.length; i++)
                        {
                            byte[] afidi = engineRef.CreateAfid(faces[i]);
                            afidsVec.add(afidi);
                            totalSize += afidi.length;
                        }
                        // match faces against each other
                        float[] scores = new float[faces.length];
                        engineRef.MatchAfids(afidsVec.get(0), afidsVec, scores);

                        float score = 0;
                        for(int i = 0; i < faces.length; i++)
                        {
                            score = 100*scores[i];
                            if(score >= minMatch){
                                sendBroadcast(true);
                            }
                        }
                    } catch (IOException e) {

                    } catch(AyonixException e) {
                        System.out.format("Caught Ayonix Error %d\n", e.errorCode);
                        e.printStackTrace();
                    }
                }
            }
        }
    };

    // Helper Functions
    private void sendBroadcast(boolean success){
        if(success){
            Intent successIntent = new Intent("unlock");
            successIntent.putExtra("success", success);
            LocalBroadcastManager.getInstance(this).sendBroadcast(successIntent);
        }
        else{
            Intent startActivity = new Intent(this, MainActivity.class);
            startActivity.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity.addCategory(Intent.CATEGORY_LAUNCHER);
            startActivity.setAction("restart");
            LocalBroadcastManager.getInstance(this).sendBroadcast(startActivity);
        }

    }

    private void stopForegroundService()
    {
        Log.d(TAG_FOREGROUND_SERVICE, "Stop foreground service.");

        // Stop foreground service and remove the notification.
        stopForeground(true);

        // Stop the foreground service.
        stopSelf();
    }


    public void onDestroy(){
        super.onDestroy();
        System.out.println("Service destroyed.");
        unregisterReceiver(receive);
        sendBroadcast(false);
        stopSelf();
    }
}