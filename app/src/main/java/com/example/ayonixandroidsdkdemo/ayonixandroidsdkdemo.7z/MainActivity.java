package com.example.ayonixandroidsdkdemo;

import android.app.KeyguardManager;
import android.content.BroadcastReceiver;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.RectF;
import android.media.MediaRecorder;
import android.os.Bundle;
import android.os.Environment;
/*import android.renderscript.Allocation;
import android.renderscript.Element;
import android.renderscript.RenderScript;
import android.renderscript.Script;
import android.renderscript.ScriptC;
import android.renderscript.Type;*/
import android.support.design.widget.FloatingActionButton;
import android.support.v4.content.LocalBroadcastManager;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.support.v8.renderscript.*;
import android.util.Log;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;

import android.content.Context;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;

import android.graphics.Bitmap;
import android.widget.Toast;

import ayonix.*;

import java.util.Collections;
import java.util.Comparator;
import java.util.Vector;

import android.Manifest;
import android.content.pm.PackageManager;
import android.graphics.ImageFormat;
import android.graphics.SurfaceTexture;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraCaptureSession;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraDevice;
import android.hardware.camera2.CameraManager;
import android.hardware.camera2.CameraMetadata;
import android.hardware.camera2.CaptureRequest;
import android.hardware.camera2.TotalCaptureResult;
import android.hardware.camera2.params.StreamConfigurationMap;
import android.media.Image;
import android.media.ImageReader;
import android.os.Handler;
import android.os.HandlerThread;
import android.support.v4.app.ActivityCompat;
import android.util.Size;
import android.util.SparseIntArray;
import android.view.Surface;
import android.view.TextureView;
import android.widget.Button;

import com.xxxyyy.testcamera2.ScriptC_yuv420888;

import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.Semaphore;

public class MainActivity extends AppCompatActivity {

    private Intent serviceIntent;
    private TextureView textureView;
    private Button enrollButton;
    protected CameraDevice cameraDevice;
    private File file;
    private HandlerThread mBackgroundThread;
    private Handler mBackgroundHandler;
    private AyonixFaceID engineRef;
    private AyonixFaceID engine;
    private AyonixFaceTracker faceTracker;
    private static final SparseIntArray ORIENTATIONS = new SparseIntArray();

    static {
        ORIENTATIONS.append(Surface.ROTATION_0, 90);
        ORIENTATIONS.append(Surface.ROTATION_90, 0);
        ORIENTATIONS.append(Surface.ROTATION_180, 270);
        ORIENTATIONS.append(Surface.ROTATION_270, 180);
    }

    private Size imageDimension;
    protected CameraCaptureSession cameraCaptureSessions;
    protected CaptureRequest captureRequest;
    protected CaptureRequest.Builder captureRequestBuilder;
    private String cameraId;
    private CaptureRequest.Builder captureBuilder;
    private ImageReader iReader;

    //Let client decide what minimum match percentage is
    private final int minMatch = 90;
    private final int detectionPeriod = 1;
    private final int minFaceSize = 40;
    private final int maxFaceSize = 300;
    private final float qualityThreshold = 0.6f;

    int width;
    int height;

    private static final int SENSOR_ORIENTATION_DEFAULT_DEGREES = 90;
    private static final int SENSOR_ORIENTATION_INVERSE_DEGREES = 270;
    private static final SparseIntArray DEFAULT_ORIENTATIONS = new SparseIntArray();
    private static final SparseIntArray INVERSE_ORIENTATIONS = new SparseIntArray();

    private static final String TAG = "Camera2VideoFragment";
    private static final int REQUEST_VIDEO_PERMISSIONS = 1;
    private static final String FRAGMENT_DIALOG = "dialog";
    private static final int REQUEST_CAMERA_PERMISSION_RESULT = 0;

    private static final String[] VIDEO_PERMISSIONS = {
            Manifest.permission.CAMERA,
            Manifest.permission.RECORD_AUDIO,
    };

    static {
        DEFAULT_ORIENTATIONS.append(Surface.ROTATION_0, 90);
        DEFAULT_ORIENTATIONS.append(Surface.ROTATION_90, 0);
        DEFAULT_ORIENTATIONS.append(Surface.ROTATION_180, 270);
        DEFAULT_ORIENTATIONS.append(Surface.ROTATION_270, 180);
    }

    static {
        INVERSE_ORIENTATIONS.append(Surface.ROTATION_0, 270);
        INVERSE_ORIENTATIONS.append(Surface.ROTATION_90, 180);
        INVERSE_ORIENTATIONS.append(Surface.ROTATION_180, 90);
        INVERSE_ORIENTATIONS.append(Surface.ROTATION_270, 0);
    }

    /**
     * An {@link AutoFitTextureView} for camera preview.
     */
    private AutoFitTextureView mTextureView;

    /**
     * Button to record video
     */
    private Button mButtonVideo;

    /**
     * A reference to the opened {@link android.hardware.camera2.CameraDevice}.
     */
    private CameraDevice mCameraDevice;

    /**
     * A reference to the current {@link android.hardware.camera2.CameraCaptureSession} for
     * preview.
     */
    private CameraCaptureSession mPreviewSession;

    /**
     * The {@link android.util.Size} of camera preview.
     */
    private Size mPreviewSize;

    /**
     * The {@link android.util.Size} of video recording.
     */
    private Size mVideoSize;

    /**
     * MediaRecorder
     */
    private MediaRecorder mMediaRecorder;

    /**
     * Whether the app is recording video now
     */
    private boolean mIsRecordingVideo;

    private Integer mSensorOrientation;

    /**
     * A {@link Semaphore} to prevent the app from exiting before closing the camera.
     */
    private Semaphore mCameraOpenCloseLock = new Semaphore(1);


   /* private LifecycleRegistry lifecycleRegistry;
    private DeviceUnlock mBoundService;
    boolean mIsBound;*/

    private BroadcastReceiver receive = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            switch (intent.getAction()) {
                case ("unlock"):
                    System.out.println("unlocking...");
                    KeyguardManager keyguardManager = (KeyguardManager) getSystemService(Context.KEYGUARD_SERVICE);
                    keyguardManager.requestDismissKeyguard(MainActivity.this, null);
                    break;
                case ("restart"):
                    System.out.println("restarting service...");
                    Intent startService = new Intent(MainActivity.this, AyonixUnlockService.class);
                    startService(startService);
                    break;
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        //set up local broadcasts to either unlock phone at lock screen, or restart service when terminated
        IntentFilter filter = new IntentFilter("unlock");
        filter.addAction("restart");
        LocalBroadcastManager.getInstance(this).registerReceiver(receive, filter);

        //start background service for lock screen
        serviceIntent = new Intent(MainActivity.this, AyonixUnlockService.class);
        serviceIntent.setAction("ACTION_START_FOREGROUND_SERVICE");
        startService(serviceIntent);

        /*Intent intent = new Intent(this, DeviceUnlock.class);
        bindService(intent, myConnection, Context.BIND_AUTO_CREATE);*/

        setContentView(R.layout.activity_main);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        setTitle("foreground service addition.");
        textureView = findViewById(R.id.texture);
        assert textureView != null;
        textureView.setSurfaceTextureListener(textureListener);
        enrollButton = findViewById(R.id.btn_enroll);
        assert enrollButton != null;
        enrollButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                enrollment();
            }
        });

        final TextView textView2 = findViewById(R.id.textView2);
        final TextView textView1 = findViewById(R.id.textView1);

        textView1.setText("Initialized\n");

        AyonixVersion ver = AyonixFaceID.GetVersion();
        textView1.setText("Ayonix FaceID v" + ver.major + "." + ver.minor + "." + ver.revision);

        // step 1. list assets (and make sure engine and test image are there)
        String engineAssetFiles[] = null;
        try {
            engineAssetFiles = getApplicationContext().getAssets().list("engine0");
        } catch (IOException e) {
        }

        // step 2. get local writable directory, and copy engine to there (for native fopen)
        String filesDir = getFilesDir().toString();

        try {
            File engineFolder = new File(filesDir + "/engine");
            engineFolder.mkdirs();
        } catch (Exception e) {
        }

        for (int i = 0; i < engineAssetFiles.length; i++) {
            String engineFilei = filesDir + "/engine/" + engineAssetFiles[i];
            try {
                InputStream fileIn = getApplicationContext().getAssets().open("engine0/" + engineAssetFiles[i]);
                FileOutputStream fileOut = new FileOutputStream(engineFilei);

                byte[] buffer = new byte[1024];
                int read = 0;
                while ((read = fileIn.read(buffer)) != -1) {
                    fileOut.write(buffer, 0, read);
                }

            } catch (IOException e) {
            }
        }

        textView1.append("Prepared engine files\n");

        // step 3. give local engine folder and license params to init the engine
        try {
            System.out.println("setting up engine.");
            engine = new AyonixFaceID(filesDir + "/engine", 816371403418L, "ju8zyppzgwh7a9qn");
            textView2.append("Loaded engine\n");

            AyonixLicenseStatus licStatus = engine.GetLicenseStatus();
            textView2.append("License " + licStatus.licId + "\n  duration " + licStatus.durationSec
                    + "s\n  remaining " + licStatus.remainingSec + "s\n");

            faceTracker = new AyonixFaceTracker(engine, detectionPeriod, minFaceSize, maxFaceSize, qualityThreshold);
            System.out.println("Face Tracker initialized.");
        } catch (AyonixException e) {
            System.out.format("Engine failed initialization with error %d\n", e.errorCode);
            e.printStackTrace();
        }
        final AyonixFaceID engineRef = engine;

        // step 4. on button click, load image and process
        final FloatingActionButton fab = findViewById(R.id.enrollButton);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                //fab.setVisibility(View.GONE);
                fab.hide();
                enrollment();

                /*InputStream fileIn = null;
                try {
                    fileIn = getApplicationContext().getAssets().open("images/angelina-jolie-brad-pitt.jpg");

                    Bitmap img = BitmapFactory.decodeStream(fileIn);

                    textView2.append("Loaded image " + img.getWidth() + "x" + img.getHeight() + "\n");

                    int pixels[] = new int[img.getWidth() * img.getHeight()];
                    byte gray[] = new byte[img.getWidth() * img.getHeight()];

                    img.getPixels(pixels, 0, img.getWidth(), 0, 0, img.getWidth(), img.getHeight());

                    for (int i = 0; i < pixels.length; i++)
                        gray[i] = (byte) (255 * Color.luminance(pixels[i]));

                    AyonixImage aimg = new AyonixImage(img.getWidth(), img.getHeight(), false, img.getWidth(), gray);

                    AyonixRect[] faceRects = engine.DetectFaces(aimg, 48);
                    textView2.append("Detected " + faceRects.length + " faces\n");

                    AyonixFace[] faces = new AyonixFace[faceRects.length];
                    for (int i = 0; i < faceRects.length; i++) {
                        faces[i] = engine.ExtractFaceFromRect(aimg, faceRects[i]);
                        textView2.append("  Face[" + (i + 1) + "] " + faceRects[i].w + "x" + faceRects[i].h + " " + (int) (faces[i].age) + "y " + (faces[i].gender > 0 ? "female" : "male") + "\n");
                    }

                    // create afids from test faces
                    Vector<byte[]> afidsVec = new Vector<byte[]>();
                    int totalSize = 0;
                    for (int i = 0; i < faces.length; i++) {
                        byte[] afidi = engine.CreateAfid(faces[i]);
                        afidsVec.add(afidi);
                        totalSize += afidi.length;
                    }
                    textView2.append("Created " + faces.length + " afids\n");
                    textView2.append("  Total " + totalSize + " bytes\n");

                    // match faces against each other
                    float[] scores = new float[faces.length];
                    engine.MatchAfids(afidsVec.get(0), afidsVec, scores);

                    textView2.append("Matched " + faces.length + " afids\n");
                    for (int i = 0; i < faces.length; i++) {
                        textView2.append("  Afid[1] vs Afid[" + (i + 1) + "]: " + (100 * scores[i]) + "\n");
                    }

                    textView2.append("Done\n");

                } catch (IOException | AyonixException e) {
                    System.out.println(Thread.currentThread().getStackTrace()[2].getLineNumber());
                    e.printStackTrace();
                }*/
            }
        });

        try {
            faceTracker = new AyonixFaceTracker(engine, detectionPeriod, minFaceSize,
                    maxFaceSize, qualityThreshold);
        } catch (AyonixException e) {
            e.printStackTrace();
        }
        System.out.println("initializes tracked " + faceTracker);

        //while(mBoundService.unlockDevice()){ }
    }

    @Override
    public void onResume(){
        super.onResume();
        if(textureView.isAvailable()){
           openCamera(textureView.getWidth(), textureView.getHeight());
        }
        else{
            textureView.setSurfaceTextureListener(textureListener);
        }
    }

    @Override
    public void onPause(){
        closeCamera();
        super.onPause();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    //-------------------------------------------------------------------------------------------
    TextureView.SurfaceTextureListener textureListener = new TextureView.SurfaceTextureListener() {
        @Override
        public void onSurfaceTextureAvailable(SurfaceTexture surface, int width, int height) {
            //open your camera here
            openCamera(width, height);
        }

        @Override
        public void onSurfaceTextureSizeChanged(SurfaceTexture surface, int width, int height) {
            // Transform you image captured size according to the surface width and height
            configureTransform(width, height);
        }

        @Override
        public boolean onSurfaceTextureDestroyed(SurfaceTexture surface) {
            return true;
        }

        @Override
        public void onSurfaceTextureUpdated(SurfaceTexture surface) {
        }
    };

    private final CameraDevice.StateCallback stateCallback = new CameraDevice.StateCallback() {
        @Override
        public void onOpened(CameraDevice camera) {
            //This is called when the camera is open
            Log.e("debug", "Camera connection established.");
            cameraDevice = camera;
            updatePreview();
        }

        @Override
        public void onDisconnected(CameraDevice camera) {
            mCameraOpenCloseLock.release();
            cameraDevice.close();
            cameraDevice = null;
        }

        @Override
        public void onError(CameraDevice camera, int error) {
            mCameraOpenCloseLock.release();
            cameraDevice.close();
            cameraDevice = null;
        }
    };

    final CameraCaptureSession.CaptureCallback captureCallbackListener = new CameraCaptureSession.CaptureCallback() {
        @Override
        public void onCaptureCompleted(CameraCaptureSession session, CaptureRequest request, TotalCaptureResult result) {
            super.onCaptureCompleted(session, request, result);
            Toast.makeText(MainActivity.this, "Saved:" + file, Toast.LENGTH_SHORT).show();
        }
    };

/*    protected void startBackgroundThread() {
        mBackgroundThread = new HandlerThread("Camera Background");
        mBackgroundThread.start();
        mBackgroundHandler = new Handler(mBackgroundThread.getLooper());
    }

    protected void stopBackgroundThread() {
        mBackgroundThread.quitSafely();
        try {
            mBackgroundThread.join();
            mBackgroundThread = null;
            mBackgroundHandler = null;
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }*/

    protected void enrollment() {
        if (null == cameraDevice) {
            Log.e("debug", "cameraDevice is null");
            return;
        }
        CameraManager manager = (CameraManager) getSystemService(Context.CAMERA_SERVICE);
        try {
            CameraCharacteristics characteristics = manager.getCameraCharacteristics(cameraDevice.getId());
            Size[] jpegSizes = null;
            if (characteristics != null) {
                jpegSizes = characteristics.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP).getOutputSizes(ImageFormat.YUV_420_888);
            }
            if (jpegSizes != null && 0 < jpegSizes.length) {
                width = jpegSizes[0].getWidth();
                height = jpegSizes[0].getHeight();
            }
            System.out.println("width: " + width + " , height: " + height);
            iReader = ImageReader.newInstance(width, height, ImageFormat.YUV_420_888, 1);
            List<Surface> outputSurfaces = new ArrayList<Surface>(2);
            outputSurfaces.add(iReader.getSurface());
            outputSurfaces.add(new Surface(textureView.getSurfaceTexture()));
            captureBuilder = cameraDevice.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE);
            captureBuilder.addTarget(iReader.getSurface());
            captureBuilder.set(CaptureRequest.CONTROL_MODE, CameraMetadata.CONTROL_MODE_AUTO);
            captureRequestBuilder.addTarget(iReader.getSurface());
            captureRequestBuilder.set(CaptureRequest.CONTROL_MODE, CameraMetadata.CONTROL_MODE_AUTO);

            // Orientation
            //int rotation = getWindowManager().getDefaultDisplay().getRotation();
            //captureBuilder.set(CaptureRequest.JPEG_ORIENTATION, ORIENTATIONS.get(rotation));
            final File file = new File(Environment.getExternalStorageDirectory() + "/pic.jpg");

            //ImageReader.OnImageAvailableListener readerListener

            iReader.setOnImageAvailableListener(new ImageReader.OnImageAvailableListener() {
                @Override
                public void onImageAvailable(ImageReader reader) {
                    Image image = null;
                    System.out.println("trying to process image!!");
                    try {
                        image = reader.acquireLatestImage();

                        int width = image.getWidth();
                        int height = image.getHeight();
                        int pixels[] = new int[width * height];
                        byte gray[] = new byte[width * height];
                        ByteBuffer buffer = image.getPlanes()[0].getBuffer();
                        byte[] data = new byte[buffer.capacity()];
                        //buffer.get(data);
                        //Bitmap bitmap = BitmapFactory.decodeByteArray(data, 0, data.length);

                        Bitmap bitmap = YUV_420_888_toRGB(image, width, height);
                        save(data);

                        bitmap.getPixels(pixels, 0, width, 0, 0, width, height);

                        for (int i = 0; i < pixels.length; i++) {
                            gray[i] = (byte) (255 * Color.luminance(pixels[i]));
                            System.out.println(data[i]);
                        }

                        AyonixImage frame = new AyonixImage(width, height, false, width, data);
                        System.out.println("got frame " + frame + ". detecting faces..");

                        AyonixRect[] faceRects = engine.DetectFaces(frame, 50);
                        AyonixFace[] faces = new AyonixFace[faceRects.length];
                        System.out.println("printing faces...");
                        for (int i = 0; i < faceRects.length; i++) {
                            try {
                                faces[i] = engine.ExtractFaceFromRect(frame, faceRects[i]);
                            } catch (AyonixException e) {
                                e.printStackTrace();
                            }
                            Log.i("info", "  Face[" + (i + 1) + "] " + faceRects[i].w + "x" +
                                    faceRects[i].h + " " + (int) (faces[i].age) + "y " +
                                    (faces[i].gender > 0 ? "female" : "male") + "\n");
                        }
                        // create afids from test faces
                        Vector<byte[]> afidsVec = new Vector<byte[]>();
                        int totalSize = 0;
                        for (int i = 0; i < faces.length; i++) {
                            byte[] afidi = new byte[0];
                            try {
                                System.out.println("creating aifd...");
                                afidi = engine.CreateAfid(faces[i]);
                            } catch (AyonixException e) {
                                e.printStackTrace();
                            }
                            afidsVec.add(afidi);
                            totalSize += afidi.length;
                        }

                        Log.i("info", "Created " + faces.length + " afids\n");
                        Log.i("info", "  Total " + totalSize + " bytes\n");

                        // match faces against each other
                        float[] scores = new float[faces.length];
                        try {
                            engine.MatchAfids(afidsVec.get(0), afidsVec, scores);
                        } catch (AyonixException e) {
                            e.printStackTrace();
                        }

                        Log.i("info", "Matched " + faces.length + " afids\n");
                        for (int i = 0; i < faces.length; i++) {
                            Log.i("info", "  Afid[1] vs Afid[" + (i + 1) + "]: " + (100 * scores[i]) + "\n");
                        }

                        Log.i("info", "Done\n");


                        try {
                            faceTracker.UpdateTracker(frame);
                        } catch (AyonixException e) {
                            e.printStackTrace();
                        }
                        image.close();

                    } catch (AyonixException | IOException e1) {
                        e1.printStackTrace();
                    } finally {
                        if (image != null) {
                            image.close();
                        }
                    }
                }

                private void save(byte[] bytes) throws IOException {
                    OutputStream output = null;
                    try {
                        output = new FileOutputStream(file);
                        output.write(bytes);
                    } finally {
                        if (null != output) {
                            output.close();
                        }
                    }
                }
            }, null);
            final CameraCaptureSession.CaptureCallback captureListener = new CameraCaptureSession.CaptureCallback() {
                @Override
                public void onCaptureCompleted(CameraCaptureSession session, CaptureRequest request, TotalCaptureResult result) {
                    super.onCaptureCompleted(session, request, result);
                    Toast.makeText(MainActivity.this, "Saved:" + file, Toast.LENGTH_SHORT).show();
                    updatePreview();
                }
            };
            cameraDevice.createCaptureSession(outputSurfaces, new CameraCaptureSession.StateCallback() {
                @Override
                public void onConfigured(CameraCaptureSession session) {
                    try {
                        session.capture(captureBuilder.build(), captureListener, null);
                    } catch (CameraAccessException e) {
                        e.printStackTrace();
                    }
                }
                @Override
                public void onConfigureFailed(CameraCaptureSession session) {
                }
            }, mBackgroundHandler);

        } catch (CameraAccessException e) {
            e.printStackTrace();
        }
    }

    private Bitmap YUV_420_888_toRGB(Image image, int width, int height){
        // Get the three image planes
        Image.Plane[] planes = image.getPlanes();
        ByteBuffer buffer = planes[0].getBuffer();
        byte[] y = new byte[buffer.remaining()];
        buffer.get(y);

        buffer = planes[1].getBuffer();
        byte[] u = new byte[buffer.remaining()];
        buffer.get(u);

        buffer = planes[2].getBuffer();
        byte[] v = new byte[buffer.remaining()];
        buffer.get(v);

        // get the relevant RowStrides and PixelStrides
        // (we know from documentation that PixelStride is 1 for y)
        int yRowStride= planes[0].getRowStride();
        int uvRowStride= planes[1].getRowStride();  // we know from   documentation that RowStride is the same for u and v.
        int uvPixelStride= planes[1].getPixelStride();  // we know from   documentation that PixelStride is the same for u and v.


        // rs creation just for demo. Create rs just once in onCreate and use it again.
        RenderScript rs = RenderScript.create(this);
        //RenderScript rs = MainActivity.rs;
        ScriptC_yuv420888 mYuv420 = new ScriptC_yuv420888 (rs);

        // Y,U,V are defined as global allocations, the out-Allocation is the Bitmap.
        // Note also that uAlloc and vAlloc are 1-dimensional while yAlloc is 2-dimensional.
        Type.Builder typeUcharY = new Type.Builder(rs, Element.U8(rs));
        typeUcharY.setX(yRowStride).setY(height);
        Allocation yAlloc = Allocation.createTyped(rs, typeUcharY.create());
        yAlloc.copyFrom(y);
        mYuv420.set_ypsIn(yAlloc);

        Type.Builder typeUcharUV = new Type.Builder(rs, Element.U8(rs));
        // note that the size of the u's and v's are as follows:
        //      (  (width/2)*PixelStride + padding  ) * (height/2)
        // =    (RowStride                          ) * (height/2)
        // but I noted that on the S7 it is 1 less...
        typeUcharUV.setX(u.length);
        Allocation uAlloc = Allocation.createTyped(rs, typeUcharUV.create());
        uAlloc.copyFrom(u);
        mYuv420.set_uIn(uAlloc);

        Allocation vAlloc = Allocation.createTyped(rs, typeUcharUV.create());
        vAlloc.copyFrom(v);
        mYuv420.set_vIn(vAlloc);

        // handover parameters
        mYuv420.set_picWidth(width);
        mYuv420.set_uvRowStride (uvRowStride);
        mYuv420.set_uvPixelStride (uvPixelStride);

        Bitmap outBitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
        Allocation outAlloc = Allocation.createFromBitmap(rs, outBitmap, Allocation.MipmapControl.MIPMAP_NONE, Allocation.USAGE_SCRIPT);

        Script.LaunchOptions lo = new Script.LaunchOptions();
        lo.setX(0, width);  // by this we ignore the y’s padding zone, i.e. the right side of x between width and yRowStride
        lo.setY(0, height);

        mYuv420.forEach_doConvert(outAlloc,lo);
        outAlloc.copyTo(outBitmap);

        return outBitmap;
    }

    private void getRGBIntFromPlanes(Image.Plane[] planes, byte[] mRgbBuffer) {
        ByteBuffer yPlane = planes[0].getBuffer();
        ByteBuffer uPlane = planes[1].getBuffer();
        ByteBuffer vPlane = planes[2].getBuffer();

        int bufferIndex = 0;
        final int total = yPlane.capacity();
        final int uvCapacity = uPlane.capacity();
        final int width = planes[0].getRowStride();

        int yPos = 0;
        for (int i = 0; i < height; i++) {
            int uvPos = (i >> 1) * width;

            for (int j = 0; j < width; j++) {
                if (uvPos >= uvCapacity-1)
                    break;
                if (yPos >= total)
                    break;

                final int y1 = yPlane.get(yPos++) & 0xff;

            /*
              The ordering of the u (Cb) and v (Cr) bytes inside the planes is a
              bit strange. The _first_ byte of the u-plane and the _second_ byte
              of the v-plane build the u/v pair and belong to the first two pixels
              (y-bytes), thus usual YUV 420 behavior. What the Android devs did
              here (IMHO): just copy the interleaved NV21 U/V data to two planes
              but keep the offset of the interleaving.
             */
                final int u = (uPlane.get(uvPos) & 0xff) - 128;
                final int v = (vPlane.get(uvPos+1) & 0xff) - 128;
                if ((j & 1) == 1) {
                    uvPos += 2;
                }

                // This is the integer variant to convert YCbCr to RGB, NTSC values.
                // formulae found at
                // https://software.intel.com/en-us/android/articles/trusted-tools-in-the-new-android-world-optimization-techniques-from-intel-sse-intrinsics-to
                // and on StackOverflow etc.
                final int y1192 = 1192 * y1;
                int r = (y1192 + 1634 * v);
                int g = (y1192 - 833 * v - 400 * u);
                int b = (y1192 + 2066 * u);

                r = (r < 0) ? 0 : ((r > 262143) ? 262143 : r);
                g = (g < 0) ? 0 : ((g > 262143) ? 262143 : g);
                b = (b < 0) ? 0 : ((b > 262143) ? 262143 : b);

                mRgbBuffer[bufferIndex++] = (byte) (((r << 6) & 0xff0000) |
                        ((g >> 2) & 0xff00) |
                        ((b >> 10) & 0xff));
            }
            System.out.println("i tried..." + i);
        }
    }

    private void setupCamera(int width, int height) {
        CameraManager manager = (CameraManager) this.getSystemService(Context.CAMERA_SERVICE);
        try {
            for (String camera : manager.getCameraIdList()) {
                CameraCharacteristics characteristics = manager.getCameraCharacteristics(camera);
                int frontCam = characteristics.get(CameraCharacteristics.LENS_FACING);
                cameraId = camera;
                if (frontCam == CameraCharacteristics.LENS_FACING_FRONT) {
                    continue;
                }
                mSensorOrientation = characteristics.get(CameraCharacteristics.SENSOR_ORIENTATION);
                StreamConfigurationMap map = characteristics.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP);
                if (map == null) {
                    throw new RuntimeException("Cannot get available preview/video sizes");
                }
                int deviceOrientation = getWindowManager().getDefaultDisplay().getRotation();
                int totalRotation = sensorToDeviceRotation(characteristics, deviceOrientation);
                boolean swapRotation = totalRotation == 90 || totalRotation == 270;
                int rotatedWidth = width;
                int rotatedHeight = height;
                if(swapRotation){
                    rotatedHeight = height;
                    rotatedWidth = width;
                }

                mPreviewSize = chooseOptimalSize(map.getOutputSizes(SurfaceTexture.class), rotatedWidth, rotatedHeight);
            }
        } catch (CameraAccessException e) {
            e.printStackTrace();
        }
    }

    private void openCamera(int width, int height) {
        if (null == this || this.isFinishing()) {
            return;
        }
        CameraManager manager = (CameraManager) this.getSystemService(Context.CAMERA_SERVICE);
        try {
            setupCamera(width,height);
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                // TODO: Consider calling
                //    ActivityCompat#requestPermissions
                // here to request the missing permissions, and then overriding
                // to handle the case where the user grants the permission. See the documentation
                // for ActivityCompat#requestPermissions for more details.
                manager.openCamera(cameraId, stateCallback, null);
            }
            else{
                if(shouldShowRequestPermissionRationale(Manifest.permission.CAMERA))
                    Toast.makeText(this, "App requires access to camera", Toast.LENGTH_SHORT).show();
                requestPermissions(new String[] {Manifest.permission.CAMERA}, REQUEST_CAMERA_PERMISSION_RESULT);
            }
        } catch (CameraAccessException e) {
            Toast.makeText(this, "Cannot access the camera.", Toast.LENGTH_SHORT).show();
            this.finish();
        }
    }

    protected void updatePreview() {
        if(null == cameraDevice) {
            Log.e("debug", "updatePreview error, return");
        }
        SurfaceTexture surfaceTexture = textureView.getSurfaceTexture();
        surfaceTexture.setDefaultBufferSize(mPreviewSize.getWidth(), mPreviewSize.getHeight());
        Surface previewSurface = new Surface(surfaceTexture);
        try {
            captureRequestBuilder = cameraDevice.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE);
            captureRequestBuilder.addTarget(previewSurface);

            cameraDevice.createCaptureSession(Arrays.asList(previewSurface), new CameraCaptureSession.StateCallback() {
                @Override
                public void onConfigured(CameraCaptureSession session) {
                    //TODO change this to a capture() for high priority
                    try {
                        session.setRepeatingRequest(captureRequestBuilder.build(), null, null);
                        //session.capture(captureRequestBuilder.build(), null, null);
                    } catch (CameraAccessException e) {;
                        e.printStackTrace();
                    }
                }
                @Override
                public void onConfigureFailed(CameraCaptureSession session) {
                    Toast.makeText(getApplicationContext(), "Unable to setup camera preview", Toast.LENGTH_SHORT).show();
                }
            }, null);
        } catch (CameraAccessException e) {
            e.printStackTrace();
        }
       /* captureRequestBuilder.set(CaptureRequest.CONTROL_MODE, CameraMetadata.CONTROL_MODE_AUTO);
        try {
            cameraCaptureSessions.setRepeatingRequest(captureRequestBuilder.build(), null, null);
        } catch (CameraAccessException e) {
            e.printStackTrace();
        }*/
    }

    private void closeCamera() {
        if (null != cameraDevice) {
            cameraDevice.close();
            cameraDevice = null;
        }
        if (null != iReader) {
            iReader.close();
            iReader = null;
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults){
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if(requestCode == REQUEST_CAMERA_PERMISSION_RESULT){
            if(grantResults[0] != PackageManager.PERMISSION_GRANTED){
                Toast.makeText(getApplicationContext(), "Application wont run without camera servies.",
                        Toast.LENGTH_SHORT).show();
            }
        }
    }

    // HELPER FUNCTIONS
    /**
     * In this sample, we choose a video size with 3x4 aspect ratio. Also, we don't use sizes
     * larger than 1080p, since MediaRecorder cannot handle such a high-resolution video.
     *
     * @param choices The list of available sizes
     * @return The video size
     */
    private static Size chooseVideoSize(Size[] choices) {
        for (Size size : choices) {
            if (size.getWidth() == size.getHeight() * 4 / 3 && size.getWidth() <= 1080) {
                return size;
            }
        }
        Log.e(TAG, "Couldn't find any suitable video size");
        return choices[choices.length - 1];
    }

    private static int sensorToDeviceRotation(CameraCharacteristics characteristics, int deviceOrientation){
        int sensorOrientation = characteristics.get(characteristics.SENSOR_ORIENTATION);
        deviceOrientation = ORIENTATIONS.get(deviceOrientation);
        return (sensorOrientation + deviceOrientation + 360) % 360;
    }

    /**
     * Given {@code choices} of {@code Size}s supported by a camera, chooses the smallest one whose
     * width and height are at least as large as the respective requested values, and whose aspect
     * ratio matches with the specified value.
     *
     * @param choices     The list of sizes that the camera supports for the intended output class
     * @param width       The minimum desired width
     * @param height      The minimum desired height
     * @return The optimal {@code Size}, or an arbitrary one if none were big enough
     */
    private static Size chooseOptimalSize(Size[] choices, int width, int height) {
        // Collect the supported resolutions that are at least as big as the preview Surface
        List<Size> bigEnough = new ArrayList<>();
        for (Size option : choices) {
            if (option.getHeight() == option.getWidth() * height / width &&
                    option.getWidth() >= width && option.getHeight() >= height) {
                bigEnough.add(option);
            }
        }

        // Pick the smallest of those, assuming we found any
        if (bigEnough.size() > 0)
            return Collections.min(bigEnough, new CompareSizesByArea());
        else {
            Log.e(TAG, "Couldn't find any suitable preview size");
            return choices[0];
        }
    }

    /**
     * Configures the necessary {@link android.graphics.Matrix} transformation to `mTextureView`.
     * This method should not to be called until the camera preview size is determined in
     * openCamera, or until the size of `mTextureView` is fixed.
     *
     * @param viewWidth  The width of `mTextureView`
     * @param viewHeight The height of `mTextureView`
     */
    private void configureTransform(int viewWidth, int viewHeight) {
        if (null == mTextureView || null == mPreviewSize || null == this) {
            return;
        }
        int rotation = this.getWindowManager().getDefaultDisplay().getRotation();
        Matrix matrix = new Matrix();
        RectF viewRect = new RectF(0, 0, viewWidth, viewHeight);
        RectF bufferRect = new RectF(0, 0, mPreviewSize.getHeight(), mPreviewSize.getWidth());
        float centerX = viewRect.centerX();
        float centerY = viewRect.centerY();
        if (Surface.ROTATION_90 == rotation || Surface.ROTATION_270 == rotation) {
            bufferRect.offset(centerX - bufferRect.centerX(), centerY - bufferRect.centerY());
            matrix.setRectToRect(viewRect, bufferRect, Matrix.ScaleToFit.FILL);
            float scale = Math.max(
                    (float) viewHeight / mPreviewSize.getHeight(),
                    (float) viewWidth / mPreviewSize.getWidth());
            matrix.postScale(scale, scale, centerX, centerY);
            matrix.postRotate(90 * (rotation - 2), centerX, centerY);
        }
        mTextureView.setTransform(matrix);
    }

    private boolean hasPermissionsGranted(String[] permissions) {
        for (String permission : permissions) {
            if (ActivityCompat.checkSelfPermission(this, permission)
                    != PackageManager.PERMISSION_GRANTED) {
                return false;
            }
        }
        return true;
    }

    /**
     * Compares two {@code Size}s based on their areas.
     */
    static class CompareSizesByArea implements Comparator<Size> {
        @Override
        public int compare(Size lhs, Size rhs) {
            // We cast here to ensure the multiplications won't overflow
            return Long.signum((long) lhs.getWidth() * lhs.getHeight() /            // -
                    (long) rhs.getWidth() * rhs.getHeight());
        }
    }
}

    /*public class DeviceLockService extends Service {

        public boolean DISMISS_KEYGUARD = false;
        private final IBinder mBinder = new LocalBinder();

        public class LocalBinder extends Binder {
            DeviceLockService getService(){
                return DeviceLockService.this;
            }
        }

        @Override
        public IBinder onBind(Intent intent) {
            return mBinder;
        }

        public boolean unlockDevice() {
            System.out.println("attempting to unlock...");
            KeyguardManager keyguardManager = (KeyguardManager) getSystemService(Context.KEYGUARD_SERVICE);
            if(keyguardManager.isKeyguardLocked() || keyguardManager.isDeviceLocked()) {
                System.out.println("detected lock..");

                //Let client decide what minimum match percentage is
                final int minMatch = 90;

                PowerManager powerManager = (PowerManager) getSystemService(Context.POWER_SERVICE);
                PowerManager.WakeLock unlock = powerManager.newWakeLock((WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
                        | PowerManager.ACQUIRE_CAUSES_WAKEUP), "ayonix::unlock");
                unlock.acquire();

                // step 1. list assets (and make sure engine and test image are there)
                String engineAssetFiles[] = null;
                try {
                    engineAssetFiles = getApplicationContext().getAssets().list("engine0");
                } catch (IOException e) {
                }

                // step 2. get local writable directory, and copy engine to there (for native fopen)
                String filesDir = getFilesDir().toString();

                try {
                    File engineFolder = new File(filesDir + "/engine");
                    engineFolder.mkdirs();
                } catch (Exception e) {
                }

                for(int i = 0; i < engineAssetFiles.length; i++) {
                    String engineFilei = filesDir + "/engine/" + engineAssetFiles[i];
                    try {
                        InputStream fileIn = getApplicationContext().getAssets().open("engine0/" + engineAssetFiles[i]);
                        FileOutputStream fileOut = new FileOutputStream(engineFilei);

                        byte[] buffer = new byte[1024];
                        int read = 0;
                        while((read = fileIn.read(buffer)) != -1){
                            fileOut.write(buffer, 0, read);
                        }

                    } catch (IOException e) {
                    }
                }

                // step 3. give local engine folder and license params to init the engine
                AyonixFaceID engine = null;
                try {
                    engine = new AyonixFaceID(filesDir + "/engine", 816371403418L, "ju8zyppzgwh7a9qn");

                    AyonixLicenseStatus licStatus = engine.GetLicenseStatus();

                } catch(AyonixException e) {
                    System.out.format("Caught Ayonix Error %d\n", e.errorCode);
                    e.printStackTrace();
                }
                final AyonixFaceID engineRef = engine;


                // step 4. on button click, load image and process

                try {
                    InputStream fileIn =  getApplicationContext().getAssets().open("images/angelina-jolie-brad-pitt.jpg");
                    Bitmap img = BitmapFactory.decodeStream(fileIn);

                    int pixels[] = new int[img.getWidth() * img.getHeight()];
                    byte gray[] = new byte[img.getWidth() * img.getHeight()];

                    img.getPixels(pixels, 0, img.getWidth(), 0, 0, img.getWidth(), img.getHeight());

                    for(int i = 0; i < pixels.length; i++)
                        gray[i] = (byte)(255 * Color.luminance(pixels[i]));

                    AyonixImage aimg = new AyonixImage(img.getWidth(), img.getHeight(), false, img.getWidth(), gray);

                    AyonixRect[] faceRects = engineRef.DetectFaces(aimg, 48);

                    AyonixFace[] faces = new AyonixFace[faceRects.length];
                    for(int i = 0; i < faceRects.length; i++)
                    {
                        faces[i] = engineRef.ExtractFaceFromRect(aimg, faceRects[i]);
                    }

                    // create afids from test faces
                    Vector<byte[]> afidsVec = new Vector<byte[]>();
                    int totalSize = 0;
                    for(int i = 0; i < faces.length; i++)
                    {
                        byte[] afidi = engineRef.CreateAfid(faces[i]);
                        afidsVec.add(afidi);
                        totalSize += afidi.length;
                    }

                    // match faces against each other
                    float[] scores = new float[faces.length];
                    engineRef.MatchAfids(afidsVec.get(0), afidsVec, scores);

                    float score = 0;
                    for(int i = 0; i < faces.length; i++)
                    {
                        score = 100*scores[i];
                        if(score >= minMatch){
                            return true;
                            unlock.release();
                            break;
                        }
                    }
                } catch (IOException e) {

                } catch(AyonixException e) {
                    System.out.format("Caught Ayonix Error %d\n", e.errorCode);
                    e.printStackTrace();
                }
            }
            else {
                System.out.println("not locked...");
            }
            return false;
        }
    }
}
*/